#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include "DHT.h"

#define DHTPIN 4
#define DHTTYPE DHT22
#define LDRPIN 34
#define LEDPIN 2

const char* ssid = "Wokwi-GUEST";
const char* password = "";

const char* mqtt_server = "45c27c642342473e85d90a96c309dee1.s1.eu.hivemq.cloud";
const int mqtt_port = 8883;
const char* mqtt_user = "davilemos";
const char* mqtt_password = "Davi102030@";

WiFiClientSecure espClient;
PubSubClient client(espClient);

DHT dht(DHTPIN, DHTTYPE);

void conectarMQTT() {
  while (!client.connected()) {
    Serial.println("Conectando ao MQTT...");

    if (client.connect("esp32_estufa_davi", mqtt_user, mqtt_password)) {
      Serial.println("MQTT conectado!");
    } else {
      Serial.print("Falhou. Codigo: ");
      Serial.println(client.state());
      delay(3000);
    }
  }
}

void setup() {
  Serial.begin(115200);

  pinMode(LEDPIN, OUTPUT);
  dht.begin();

  WiFi.begin(ssid, password);
  Serial.print("Conectando ao WiFi");

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("WiFi conectado!");

  espClient.setInsecure();

  client.setServer(mqtt_server, mqtt_port);
}

void loop() {
  if (!client.connected()) {
    conectarMQTT();
  }

  client.loop();

  float temperatura = dht.readTemperature();
  float umidade = dht.readHumidity();
  int luminosidade = analogRead(LDRPIN);

  if (temperatura > 30) {
    digitalWrite(LEDPIN, HIGH);
  } else {
    digitalWrite(LEDPIN, LOW);
  }

  char tempStr[10];
  char umidStr[10];
  char luzStr[10];

  dtostrf(temperatura, 4, 2, tempStr);
  dtostrf(umidade, 4, 2, umidStr);
  sprintf(luzStr, "%d", luminosidade);

  client.publish("estufa1/temperatura", tempStr);
  client.publish("estufa1/umidade", umidStr);
  client.publish("estufa1/luminosidade", luzStr);

  String dadosJson = "{";
  dadosJson += "\"temperatura\":" + String(temperatura, 2) + ",";
  dadosJson += "\"umidade\":" + String(umidade, 2) + ",";
  dadosJson += "\"luminosidade\":" + String(luminosidade);
  dadosJson += "}";

  client.publish("estufa1/dados", dadosJson.c_str());

  Serial.println("Dados enviados via MQTT:");
  Serial.println(dadosJson);

  delay(3000);
}